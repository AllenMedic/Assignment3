package com.jyz.thread;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.mysql.jdbc.PreparedStatement;

public class Main2014302580333 {
	//存储老师的url
		static ArrayList<String> listUrl = new ArrayList<String>();
		//存储老师的名字
		static ArrayList<String> listNameS = new ArrayList<String>();
		static ArrayList<String> listNameM = new ArrayList<String>();
		//存储老师的电话
		static ArrayList<String> listEmaS = new ArrayList<String>();
		static ArrayList<String> listEmaM = new ArrayList<String>();
		//存储老师的简介
		static ArrayList<String> listIntS = new ArrayList<String>();
		static ArrayList<String> listIntM = new ArrayList<String>();
		Connection con;
		Statement sta;
		public Main2014302580333() {}
		
		public void getURL() {
			//得到主页里面所有老师的URL
					Document doc = null;
					Document doct= null;
					int ii=0;
					boolean con=true;
					try {
						doc = Jsoup.connect("https://www.wpi.edu/academics/cs/research-interests.html").timeout(5000).get();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Elements url = doc.select("div.half").select("a[href]");
					System.out.println("开始获取老师的URL");
					for (int i = 0;i<url.size(); i++) {
						try {
							doct=Jsoup.connect(url.get(i).attr("href")).get();
							con=true;
						} catch (IOException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
							con=false;
						}
						if(con){
							listUrl.add(url.get(i).attr("href"));
							System.out.println("正在存储第" + (ii + 1) + "个老师的url："+listUrl.get(ii));
							ii++;
						}
					}
					System.out.println(ii+"个老师的URL储存完毕");

			
		}
		public void get_S(){
			System.out.println("-----------------------开始运行单线程-----------------------------");
			long startTime= System.currentTimeMillis();//获取当前时间
			for(int i=0;i<listUrl.size();i++){
				System.out.println("正在爬取第"+(i+1)+"个老师的信息");
				Document doc = null;
				try {
					doc = Jsoup.connect(listUrl.get(i)).timeout(5000).get();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Element name = doc.select("#content>h2").first();
				listNameS.add(name.text());
				
				Element email = doc.select("#contactinfo>p>a[href]").first();
				listEmaS.add(email.text());
				
				Element intro = doc.select("#content>p").first();
				listIntS.add(intro.text());
				
				
				System.out.println("获取第"+(i+1)+"个老师的信息为：  "+listNameS.get(i)+"    "+"邮箱：  "+listEmaS.get(i));
				System.out.println(listIntS.get(i));
				
			}
			long endTime = System.currentTimeMillis();
			showTime(startTime, endTime);
			System.out.println("-----------------------单线程运行结束-----------------------------");

		}
		
		//得到系统的运行时间
		public static void showTime(long startTime,long endTime){
				System.out.println("程序运行时间："+(endTime-startTime)+"ms");
		}
		

			public void setSQL(){
				try{
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_schema", "root", "shui7zhidao");
					sta=con.createStatement();
					System.out.println("开始创建数据库的表");
					sta.execute("create table if not exists S_thread(name varchar(255),email varchar(255), intro text);");
					System.out.println("单线程的数据库的表已经创建");
					sta.execute("create table if not exists M_thread(name varchar(255),email varchar(255), intro text);");
					System.out.println("多线程的数据库的表已经创建");
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
			public void insert_S() throws SQLException{
				String sql = "insert into S_thread(name,email,intro) values(?,?,?)；";
				PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
				for(int i=0;i<listUrl.size();i++){
					ps.setObject(1, listNameS.get(i));
					ps.setObject(2, listEmaS.get(i));
					ps.setObject(3, listIntS.get(i));
				}
				System.out.println("单线程数据库已写入完毕");
				
			}
			public void insert_M() throws SQLException{
				String sql = "insert into M_thread(name,email,intro) values(?,?,?);";
				PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
				for(int i=0;i<listUrl.size();i++){
					ps.setObject(1, listNameM.get(i));
					ps.setObject(2, listEmaM.get(i));
					ps.setObject(3, listIntM.get(i));
				}
				System.out.println("多线程数据库已写入完毕");
				
			}
	public static void main(String[] args){
		Main2014302580333 teacher=new Main2014302580333();
		teacher.getURL();
		teacher.get_S();
		teacher.setSQL();
		try {
			teacher.insert_S();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
	}

}
